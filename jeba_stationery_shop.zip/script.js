const products = [
  {id:1,name:"Pastel Study Notebook",category:"Notebooks",price:89,old:120,emoji:"📒",bg:"#f8e1e5",badge:"BESTSELLER"},
  {id:2,name:"Color Pop Gel Pens",category:"Pens",price:129,old:159,emoji:"🖊️",bg:"#e5e0f7",badge:"SET OF 6"},
  {id:3,name:"Cute Sticky Notes",category:"Accessories",price:59,old:79,emoji:"🗒️",bg:"#fce9c9",badge:"POPULAR"},
  {id:4,name:"Artist Color Pencils",category:"Art",price:149,old:189,emoji:"🖍️",bg:"#dcebd7",badge:""},
  {id:5,name:"Daily Planner",category:"Notebooks",price:179,old:220,emoji:"📔",bg:"#dce8f7",badge:"NEW"},
  {id:6,name:"Classic Pencil Set",category:"Pens",price:49,old:65,emoji:"✏️",bg:"#f7dfd2",badge:"VALUE PICK"},
  {id:7,name:"Mini Desk Organizer",category:"Accessories",price:199,old:249,emoji:"🗃️",bg:"#eee2d7",badge:""},
  {id:8,name:"Watercolor Paint Kit",category:"Art",price:229,old:279,emoji:"🎨",bg:"#e8e0f4",badge:"CREATIVE PICK"}
];
const $ = id => document.getElementById(id);
let cart = JSON.parse(localStorage.getItem("jebaCart") || "[]");
let favorites = JSON.parse(localStorage.getItem("jebaFavorites") || "[]");
let activeCategory = "All";
let viewMode = "shop";

function saveState(){localStorage.setItem("jebaCart",JSON.stringify(cart));localStorage.setItem("jebaFavorites",JSON.stringify(favorites));updateCounts();}
function updateCounts(){$("cartCount").textContent=cart.reduce((n,i)=>n+i.qty,0);$("favoriteCount").textContent=favorites.length;}
function money(value){return "₹"+value.toFixed(0);}
function renderProducts(){
  const query=$("searchInput").value.trim().toLowerCase();
  let shown=products.filter(p=>(activeCategory==="All"||p.category===activeCategory)&&(!query||(p.name+" "+p.category).toLowerCase().includes(query)));
  if(viewMode==="favorites") shown=shown.filter(p=>favorites.includes(p.id));
  $("resultLabel").textContent=viewMode==="favorites"?"Your saved items":`${shown.length} item${shown.length===1?"":"s"} to discover`;
  $("productGrid").innerHTML=shown.map(p=>`<article class="product-card">
    <div class="product-visual" style="background:${p.bg}">${p.badge?`<span class="badge">${p.badge}</span>`:""}<button class="heart-btn ${favorites.includes(p.id)?"favorited":""}" data-favorite="${p.id}" aria-label="Add ${p.name} to favorites">${favorites.includes(p.id)?"♥":"♡"}</button><span class="product-emoji">${p.emoji}</span></div>
    <div class="product-info"><div class="product-category">${p.category}</div><h3 class="product-name">${p.name}</h3><div class="product-bottom"><div><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span></div><button class="add-btn" data-add="${p.id}">+ Add</button></div></div>
  </article>`).join("");
  $("emptyState").hidden=shown.length!==0;
}
function showToast(message){$("toast").textContent=message;$("toast").classList.add("show");setTimeout(()=>$("toast").classList.remove("show"),2100);}
function addToCart(id){const found=cart.find(i=>i.id===id);if(found)found.qty++;else cart.push({id,qty:1});saveState();showToast("Added to your cart ♡");}
function toggleFavorite(id){favorites=favorites.includes(id)?favorites.filter(x=>x!==id):[...favorites,id];saveState();renderProducts();showToast(favorites.includes(id)?"Saved to favorites ♥":"Removed from favorites");}
function openPanel(mode){
  viewMode=mode;$("panelEyebrow").textContent=mode==="cart"?"YOUR BAG":"SAVED WITH LOVE";$("panelTitle").textContent=mode==="cart"?"Shopping cart":"Your favorites";
  $("panelItems").innerHTML="";
  if(mode==="cart"){
    if(!cart.length){$("panelItems").innerHTML='<div class="panel-empty"><span>🛍️</span>Your cart is waiting for something lovely.</div>';$("panelBottom").innerHTML='<p class="shipping-note">Add a few stationery favorites to get started.</p><button class="checkout-btn" id="continueShopping">Continue shopping</button>';}
    else{
      $("panelItems").innerHTML=cart.map(item=>{const p=products.find(x=>x.id===item.id);return `<div class="panel-row"><div class="mini-visual" style="background:${p.bg}">${p.emoji}</div><div><h4>${p.name}</h4><small>${money(p.price)} each</small><div class="qty"><button data-qty="${p.id}" data-change="-1">−</button><span>${item.qty}</span><button data-qty="${p.id}" data-change="1">+</button></div></div><div><div class="row-price">${money(p.price*item.qty)}</div><button class="remove-item" data-remove="${p.id}">Remove</button></div></div>`}).join("");
      const total=cart.reduce((n,i)=>n+products.find(p=>p.id===i.id).price*i.qty,0);
      $("panelBottom").innerHTML=`<div class="total-row"><span>Subtotal</span><span>${money(total)}</span></div><p class="shipping-note">Delivery charges, if any, are calculated separately. Demo checkout only.</p><button class="checkout-btn" id="checkoutBtn">Proceed to checkout →</button><button class="clear-btn" id="clearCart">Clear cart</button>`;
    }
  }else{
    const favProducts=products.filter(p=>favorites.includes(p.id));
    if(!favProducts.length){$("panelItems").innerHTML='<div class="panel-empty"><span>♡</span>No favorites yet. Tap the heart on a product you love.</div>';$("panelBottom").innerHTML='<button class="checkout-btn" id="continueShopping">Explore products</button>';}
    else{$("panelItems").innerHTML=favProducts.map(p=>`<div class="panel-row"><div class="mini-visual" style="background:${p.bg}">${p.emoji}</div><div><h4>${p.name}</h4><small>${money(p.price)}</small><div class="qty"><button data-add="${p.id}">+ Add to cart</button></div></div><button class="remove-item" data-favorite="${p.id}">♥ Remove</button></div>`).join("");$("panelBottom").innerHTML='<button class="checkout-btn" id="continueShopping">Continue shopping</button>';}
  }
  $("sidePanel").classList.add("open");$("overlay").classList.add("open");$("sidePanel").setAttribute("aria-hidden","false");
}
function closePanel(){$("sidePanel").classList.remove("open");$("overlay").classList.remove("open");$("sidePanel").setAttribute("aria-hidden","true");}
$("productGrid").addEventListener("click",e=>{const add=e.target.closest("[data-add]");const fav=e.target.closest("[data-favorite]");if(add)addToCart(Number(add.dataset.add));if(fav)toggleFavorite(Number(fav.dataset.favorite));});
$("filters").addEventListener("click",e=>{const btn=e.target.closest("[data-category]");if(!btn)return;activeCategory=btn.dataset.category;document.querySelectorAll(".filter").forEach(b=>b.classList.toggle("active",b===btn));viewMode="shop";renderProducts();});
$("searchInput").addEventListener("input",()=>{viewMode="shop";renderProducts();});
$("searchBtn").addEventListener("click",()=>{viewMode="shop";renderProducts();$("shop").scrollIntoView({behavior:"smooth"});});
$("cartNav").addEventListener("click",()=>openPanel("cart"));$("favoritesNav").addEventListener("click",()=>openPanel("favorites"));$("closePanel").addEventListener("click",closePanel);$("overlay").addEventListener("click",closePanel);
$("panelItems").addEventListener("click",e=>{
 const qty=e.target.closest("[data-qty]"),remove=e.target.closest("[data-remove]"),fav=e.target.closest("[data-favorite]"),add=e.target.closest("[data-add]");
 if(qty){const id=Number(qty.dataset.qty),item=cart.find(i=>i.id===id);if(item){item.qty+=Number(qty.dataset.change);if(item.qty<=0)cart=cart.filter(i=>i.id!==id);}saveState();openPanel("cart");}
 if(remove){cart=cart.filter(i=>i.id!==Number(remove.dataset.remove));saveState();openPanel("cart");}
 if(fav){toggleFavorite(Number(fav.dataset.favorite));openPanel("favorites");}
 if(add){addToCart(Number(add.dataset.add));openPanel("favorites");}
});
$("panelBottom").addEventListener("click",e=>{
 if(e.target.id==="continueShopping")closePanel();
 if(e.target.id==="clearCart"){cart=[];saveState();openPanel("cart");showToast("Cart cleared");}
 if(e.target.id==="checkoutBtn"){const total=cart.reduce((n,i)=>n+products.find(p=>p.id===i.id).price*i.qty,0);alert(`Thank you for trying Jeba Stationery!\\nYour demo order total is ${money(total)}.\\nThis mini project does not process real payments.`);cart=[];saveState();openPanel("cart");}
});
$("year").textContent=new Date().getFullYear();updateCounts();renderProducts();
