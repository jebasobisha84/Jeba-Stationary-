JEBA STATIONERY — MINI PROJECT
================================
Files:
- index.html : website structure
- style.css  : design and responsive layout
- script.js  : product listing, search, category filters, favorites, cart and demo checkout

HOW TO OPEN:
1. Extract jeba_stationery_shop.zip.
2. Open the folder and double-click index.html. It opens in your browser.
3. For a public website link, publish the files using GitHub Pages:
   - Sign in to GitHub and create a new public repository (example: jeba-stationery).
   - Upload index.html, style.css and script.js to the repository root.
   - Open Settings > Pages.
   - Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
   - Wait for deployment; GitHub will show your public website URL.
Note: Checkout is a demo and does not collect payments or place real orders.
